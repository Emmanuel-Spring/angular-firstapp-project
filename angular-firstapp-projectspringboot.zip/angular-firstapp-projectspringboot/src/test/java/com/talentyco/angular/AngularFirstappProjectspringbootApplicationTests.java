package com.talentyco.angular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularFirstappProjectspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
